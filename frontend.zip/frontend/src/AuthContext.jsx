// AuthContext.jsx
// import React, { createContext, useContext, useState, useEffect } from "react";

// const AuthContext = createContext();

// export const useAuth = () => useContext(AuthContext);

// export const AuthProvider = ({ children }) => {
//   // Track whether the user is authenticated
//   const [isAuthenticated, setIsAuthenticated] = useState(() => {
//     return localStorage.getItem("isAuthenticated") === "true";
//   });

//   // Store the JWT/access token
//   const [authToken, setAuthToken] = useState(() => {
//     return localStorage.getItem("token") || null;
//   });

//   // Call this to log in and save the token
//   const login = (token) => {
//     localStorage.setItem("isAuthenticated", "true");
//     localStorage.setItem("token", token);
//     setIsAuthenticated(true);
//     setAuthToken(token);
//   };

//   // Call this to log out and clear everything
//   const logout = () => {
//     localStorage.removeItem("isAuthenticated");
//     localStorage.removeItem("token");
//     setIsAuthenticated(false);
//     setAuthToken(null);
//   };

//   // Keep localStorage in sync if isAuthenticated changes (optional but retained from original)
//   useEffect(() => {
//     const stored = localStorage.getItem("isAuthenticated");
//     if (stored !== String(isAuthenticated)) {
//       localStorage.setItem("isAuthenticated", String(isAuthenticated));
//     }
//   }, [isAuthenticated]);

//   return (
//     <AuthContext.Provider value={{ isAuthenticated, authToken, login, logout }}>
//       {children}
//     </AuthContext.Provider>
//   );
// };

// AuthContext.jsx
import React, { createContext, useContext, useState, useEffect } from "react";

const AuthContext = createContext();
export const useAuth = () => useContext(AuthContext);

export const AuthProvider = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(() => {
    return localStorage.getItem("isAuthenticated") === "true";
  });

  const [authToken, setAuthToken] = useState(() => {
    return localStorage.getItem("token") || null;
  });

  // Store “username” (in our case, the email) so Home.jsx can build a stable key
  const [username, setUsername] = useState(() => {
    return localStorage.getItem("username") || "";
  });

  // New login signature: login(token, usernameValue)
  const login = (token, usernameValue) => {
    localStorage.setItem("token", token);
    localStorage.setItem("username", usernameValue);
    localStorage.setItem("isAuthenticated", "true");
    setAuthToken(token);
    setUsername(usernameValue);
    setIsAuthenticated(true);
  };

  const logout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("username");
    localStorage.removeItem("isAuthenticated");
    setAuthToken(null);
    setUsername("");
    setIsAuthenticated(false);
  };

  // Keep localStorage in sync if isAuthenticated changes
  useEffect(() => {
    const stored = localStorage.getItem("isAuthenticated");
    if (stored !== String(isAuthenticated)) {
      localStorage.setItem("isAuthenticated", String(isAuthenticated));
    }
  }, [isAuthenticated]);

  return (
    <AuthContext.Provider
      value={{ isAuthenticated, authToken, username, login, logout }}
    >
      {children}
    </AuthContext.Provider>
  );
};

