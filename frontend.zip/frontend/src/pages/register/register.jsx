// FRONTEND/src/pages/register/Register.jsx
import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { registerUser } from "../../api"; // our helper for POST /auth/register
import Home from "../../assets/home.jpg";
import "./register.scss";

const Register = () => {
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      // Send username, email, and password to your backend’s /auth/register
      await registerUser({ username, email, password });
      alert("Registration successful! Please log in.");
      navigate("/login");
    } catch (err) {
      console.error("Registration failed:", err);
      alert("Registration failed. Try again.");
    }
  };

  return (
    <div className="rcontainer">
      <img className="mimg" src={Home} alt="Home" />
      <div className="register-container">
        <h1>Welcome To X-Vision</h1>
        <div className="access-buttons">
          <Link to={"/login"}>
            <button>Sign in</button>
          </Link>
          <button>Register</button>
        </div>
        <form onSubmit={handleSubmit} className="register-form">
          <input
            type="text"
            placeholder="Username"
            value={username}
            required
            onChange={(e) => setUsername(e.target.value)}
          />
          <input
            type="email"
            placeholder="Email"
            value={email}
            required
            onChange={(e) => setEmail(e.target.value)}
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            required
            onChange={(e) => setPassword(e.target.value)}
          />
          <button type="submit">Register</button>
        </form>
      </div>
    </div>
  );
};

export default Register;
