// src/pages/login/Login.jsx
// import React, { useState } from "react";
// import { Link, useNavigate } from "react-router-dom";
// import { useAuth } from "../../AuthContext";
// import Home from "../../assets/home.jpg";
// import { loginUser } from "../../api";
// import "./login.scss";

// const Login = () => {
//   const [email, setEmail] = useState("");
//   const [password, setPassword] = useState("");
//   const { login } = useAuth();
//   const navigate = useNavigate();

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     try {
//       const response = await loginUser({ username: email, password });
//       const token = response.data.access_token;
//       login(token);
//       navigate("/home");
//     } catch (err) {
//       console.error("Login failed:", err.response?.status, err.response?.data);
//       alert("Invalid credentials");
//     }
//   };

//   return (
//     <div className="lcontainer">
//       <img src={Home} alt="Home" />
//       <div className="login-container">
//         <h1>Welcome To X-Vision</h1>
//         <div className="access-buttons">
//           <button>Sign in</button>
//           <Link to="/register">
//             <button>Register</button>
//           </Link>
//         </div>
//         <form onSubmit={handleSubmit} className="login-form">
//           <input
//             type="text"
//             placeholder="Email"
//             value={email}
//             required
//             onChange={(e) => setEmail(e.target.value)}
//           />
//           <input
//             type="password"
//             placeholder="Password"
//             value={password}
//             required
//             onChange={(e) => setPassword(e.target.value)}
//           />
//           <button type="submit">Login</button>
//         </form>
//       </div>
//     </div>
//   );
// };

// export default Login;


import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../../AuthContext";
import Home from "../../assets/home.jpg";
import { loginUser } from "../../api";
import "./login.scss";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await loginUser({ username: email, password });
      const token = response.data.access_token;

-     // Pass only the token here before. We need to also pass email.
-     login(token);
+     // Now pass both token AND email (so AuthContext can store "username" = email)
+     login(token, email);

      navigate("/home");
    } catch (err) {
      console.error("Login failed:", err.response?.status, err.response?.data);
      alert("Invalid credentials");
    }
  };

  return (
    <div className="lcontainer">
      <img src={Home} alt="Home" />
      <div className="login-container">
        <h1>Welcome To X-Vision</h1>
        <div className="access-buttons">
          <button>Sign in</button>
          <Link to="/register">
            <button>Register</button>
          </Link>
        </div>
        <form onSubmit={handleSubmit} className="login-form">
          <input
            type="text"
            placeholder="Email"
            value={email}
            required
            onChange={(e) => setEmail(e.target.value)}
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            required
            onChange={(e) => setPassword(e.target.value)}
          />
          <button type="submit">Login</button>
        </form>
      </div>
    </div>
  );
};

export default Login;
