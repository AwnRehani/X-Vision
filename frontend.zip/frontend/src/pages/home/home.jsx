// // src/pages/home/Home.jsx
// import React, { useState } from "react";
// import { useNavigate } from "react-router-dom";
// import { predictXray } from "../../api";
// import { useAuth } from "../../AuthContext";
// import "./home.scss";

// export default function Home() {
//   const { authToken, logout } = useAuth();
//   const navigate = useNavigate();
//   const [image, setImage] = useState(null);
//   const [result, setResult] = useState(null);

//   if (!authToken) {
//     navigate("/login");
//     return null;
//   }

//   const handleChange = (e) => {
//     setImage(e.target.files[0]);
//   };

//   const handlePress = async () => {
//     if (!image) {
//       alert("Please select an X-ray file first.");
//       return;
//     }
//     try {
//       const predRes = await predictXray(image, authToken);
//       setResult(predRes.data);
//     } catch (err) {
//       console.error("Error during predict:", err.response?.status, err.response?.data);
//       alert("Something went wrong. Please try again.");
//     }
//   };

//   const handleLogout = () => {
//     logout();
//     navigate("/login");
//   };

//   return (
//     <div className="home-container">
//       <button className="logout-button" onClick={handleLogout}>
//         Logout
//       </button>
//       <input
//         onChange={handleChange}
//         name="file"
//         type="file"
//         accept="image/*"
//       />
//       <button className="next-button" onClick={handlePress}>
//         NEXT
//       </button>
//       {result && (
//         <div className="diagnosis-container">
//           <h2>Diagnosis: {result.label}</h2>
//           <p>Confidence: {(result.confidence * 100).toFixed(1)}%</p>
//           {result.annotated_image_url && (
//             <img
//               src={result.annotated_image_url}
//               alt="Annotated X-ray"
//               style={{ maxWidth: "400px" }}
//             />
//           )}
//           <pre>{result.report}</pre>
//           <button className="x-button">X</button>
//         </div>
//       )}
//     </div>
//   );
// }

// src/pages/home/Home.jsx

////////////////////////////////////////////////

// import React, { useState } from "react";
// import { useNavigate } from "react-router-dom";
// import { predictXray } from "../../api";
// import { useAuth } from "../../AuthContext";
// import "./home.scss";

// export default function Home() {
//   const { authToken, logout } = useAuth();
//   const navigate = useNavigate();
//   const [image, setImage] = useState(null);
//   const [filename, setFilename] = useState("");
//   const [result, setResult] = useState(null);
//   const [isLoading, setIsLoading] = useState(false);

//   if (!authToken) {
//     navigate("/login");
//     return null;
//   }

//   const handleChange = (e) => {
//     const file = e.target.files[0];
//     if (file) {
//       setImage(file);
//       setFilename(file.name);
//     }
//   };

//   const handlePress = async () => {
//     if (!image) {
//       alert("Please select an X-ray file first.");
//       return;
//     }
//     setIsLoading(true);
//     try {
//       const predRes = await predictXray(image, authToken);
//       setResult(predRes.data);
//     } catch (err) {
//       console.error("Error during predict:", err.response?.status, err.response?.data);
//       alert("Something went wrong. Please try again.");
//     } finally {
//       setIsLoading(false);
//     }
//   };

//   const handleLogout = () => {
//     logout();
//     navigate("/login");
//   };

//   const handleCloseResult = () => {
//     // Clear result so the user can run a new prediction
//     setResult(null);
//     setFilename("");
//     setImage(null);
//   };

//   return (
//     <div className="home-container">
//       {/* Card with Logout, File Picker, NEXT - always visible */}
//       <div className="card">
//         <button className="logout-icon" onClick={handleLogout} title="Logout">
//           logout
//         </button>
//         <h1 className="card-title">Upload X-ray for Diagnosis</h1>

//         {/* Custom file picker label */}
//         <label htmlFor="file-input" className="file-label">
//           <span className="upload-icon">📁</span>
//           <span className="file-label-text">
//             {filename || "Choose an X-ray file"}
//           </span>
//         </label>
//         <input
//           id="file-input"
//           type="file"
//           accept="image/*"
//           onChange={handleChange}
//         />

//         {/* NEXT button */}
//         <button
//           className="next-button"
//           onClick={handlePress}
//           disabled={isLoading}
//         >
//           {isLoading ? "Processing..." : "NEXT"}
//         </button>
//       </div>

//       {/* Diagnosis results appear below when available */}
//       {result && (
//         <div className="diagnosis-container">
//           <h2>Diagnosis: {result.label}</h2>
//           <p>Confidence: {(result.confidence * 100).toFixed(1)}%</p>
//           {result.annotated_image_url && (
//             <img
//               src={result.annotated_image_url}
//               alt="Annotated X-ray"
//               className="annotated-xray"
//             />
//           )}
//           <pre>{result.report}</pre>
//           <button className="x-button">
//             X
//           </button>
//         </div>
//       )}
//     </div>
//   );
// }

import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { predictXray } from "../../api";
import { useAuth } from "../../AuthContext";
import "./home.scss";

export default function Home() {
  const { authToken, username, logout } = useAuth(); // assumes AuthContext provides a stable `username`
  const navigate = useNavigate();
  const [image, setImage] = useState(null);
  const [filename, setFilename] = useState("");
  const [result, setResult] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  // History state, scoped per username
  const [history, setHistory] = useState([]);
  const [selectedHistory, setSelectedHistory] = useState(null);

  // Use a key based on the username (not the token) so that logging out and back in
  // as the same user still retrieves that user's history.
  const storageKey = `xrayHistory_${username}`;

  // Load that user's history from localStorage whenever the username becomes available
  useEffect(() => {
    if (!username) return;
    const stored = localStorage.getItem(storageKey);
    if (stored) {
      try {
        setHistory(JSON.parse(stored));
      } catch {
        console.warn("Could not parse history from localStorage");
      }
    } else {
      setHistory([]);
    }
    // Clear any selected display when the user changes or on first load
    setSelectedHistory(null);
    setResult(null);
    setFilename("");
    setImage(null);
  }, [username]);

  // If not authenticated, redirect to login
  if (!authToken) {
    navigate("/login");
    return null;
  }

  // Helper: convert File to a base64 data URL
  const fileToDataUrl = (file) =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => resolve(e.target.result);
      reader.onerror = (e) => reject(e);
      reader.readAsDataURL(file);
    });

  const handleChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setImage(file);
      setFilename(file.name);
      setSelectedHistory(null);
    }
  };

  const handlePress = async () => {
    if (!image) {
      alert("Please select an X-ray file first.");
      return;
    }
    setIsLoading(true);
    try {
      const predRes = await predictXray(image, authToken);
      const data = predRes.data;
      setResult(data);

      const originalDataUrl = await fileToDataUrl(image);
      const newEntry = {
        id: Date.now(),
        imageDataUrl: originalDataUrl,
        result: data,
      };
      const updated = [newEntry, ...history];
      setHistory(updated);
      localStorage.setItem(storageKey, JSON.stringify(updated));
      setSelectedHistory(null);
    } catch (err) {
      console.error("Error during predict:", err.response?.status, err.response?.data);
      alert("Something went wrong. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  const handleCloseResult = () => {
    setResult(null);
    setFilename("");
    setImage(null);
    setSelectedHistory(null);
  };

  const handleSelectHistory = (entry) => {
    setSelectedHistory(entry);
    setResult(null);
    setFilename("");
    setImage(null);
  };

  const handleDeleteAll = () => {
    if (window.confirm("Are you sure you want to delete all history?")) {
      localStorage.removeItem(storageKey);
      setHistory([]);
      setSelectedHistory(null);
      setResult(null);
    }
  };

  // Decide which data to show: a previously selected history item or the fresh `result`
  const displayItem = selectedHistory ? selectedHistory.result : result;

  return (
    <div
      className="home-container"
      style={{ flexDirection: "row", alignItems: "flex-start" }}
    >
      {/* ---------- History Sidebar ---------- */}
      <div
        style={{
          width: 220,
          maxHeight: "80vh",
          overflowY: "auto",
          marginRight: 16,
          padding: 8,
          backgroundColor: "#1e293b",
          borderRadius: 8,
        }}
      >
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            marginBottom: 12,
          }}
        >
          <h2 style={{ color: "#ffffff", fontSize: "1.2rem", margin: 0 }}>
            History
          </h2>
          <button
            onClick={handleDeleteAll}
            style={{
              backgroundColor: "#dc2626",
              color: "#ffffff",
              border: "none",
              borderRadius: 4,
              padding: "4px 8px",
              fontSize: "0.8rem",
              cursor: "pointer",
            }}
          >
            Delete All
          </button>
        </div>

        {history.length === 0 && (
          <p style={{ color: "#ffffff80", fontSize: "0.9rem" }}>
            No history yet.
          </p>
        )}
        {history.map((entry) => (
          <div
            key={entry.id}
            onClick={() => handleSelectHistory(entry)}
            style={{
              cursor: "pointer",
              marginBottom: 12,
              padding: 8,
              backgroundColor:
                selectedHistory?.id === entry.id ? "#3b82f6" : "#2c3a47",
              borderRadius: 6,
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
            }}
          >
            <img
              src={entry.imageDataUrl}
              alt="thumbnail"
              style={{
                width: "100%",
                height: 100,
                objectFit: "cover",
                borderRadius: 4,
                marginBottom: 8,
              }}
            />
            <span
              style={{
                color: "#ffffff",
                fontSize: "0.9rem",
                textAlign: "center",
                whiteSpace: "nowrap",
                overflow: "hidden",
                textOverflow: "ellipsis",
                width: "100%",
              }}
            >
              {entry.result.label} (
              {(entry.result.confidence * 100).toFixed(1)}%)
            </span>
          </div>
        ))}
      </div>

      {/* ---------- Main Content: Upload Card + Result ---------- */}
      <div
        style={{
          flex: 1,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        {/* Centered Upload Card */}
        <div className="card">
          <button className="logout-icon" onClick={handleLogout} title="Logout">
            logout
          </button>
          <h1 className="card-title">Upload X-ray for Diagnosis</h1>

          <label htmlFor="file-input" className="file-label">
            <span className="upload-icon">📁</span>
            <span className="file-label-text">
              {filename || "Choose an X-ray file"}
            </span>
          </label>
          <input
            id="file-input"
            type="file"
            accept="image/*"
            onChange={handleChange}
          />

          <button
            className="next-button"
            onClick={handlePress}
            disabled={isLoading}
          >
            {isLoading ? "Processing..." : "NEXT"}
          </button>
        </div>

        {/* Diagnosis Results */}
        {displayItem && (
          <div className="diagnosis-container">
            <h2>Diagnosis: {displayItem.label}</h2>
            <p>Probability of Fracture: {(displayItem.confidence * 100).toFixed(1)}%</p>
            {displayItem.annotated_image_url && (
              <img
                src={displayItem.annotated_image_url}
                alt="Annotated X-ray"
                className="annotated-xray"
              />
            )}
            <pre>{displayItem.report}</pre>
            <button className="x-button" onClick={handleCloseResult}>
              X
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
