// FRONTEND/src/api.js
import axios from "axios";

// 1) Login: calls POST /auth/login with URL-encoded form data
export function loginUser({ username, password }) {
  const formData = new URLSearchParams();
  formData.append("username", username);
  formData.append("password", password);

  return axios.post("/auth/login", formData, {
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
  });
}

// 2) Register: calls POST /auth/signup
// Expects an object like { username, email, password }
export function registerUser(data) {
  return axios.post("/auth/signup", data);
}

// 3) Predict + LLM Report: calls POST /predict/all
// Sends the X-ray file directly as multipart/form-data
export function predictXray(file, token) {
  const formData = new FormData();
  formData.append("xray_file", file);

  return axios.post("/predict/all", formData, {
    headers: {
      "Content-Type": "multipart/form-data",
      ...(token && { Authorization: `Bearer ${token}` }),
    },
  });
}
